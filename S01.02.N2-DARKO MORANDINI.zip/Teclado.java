import java.util.InputMismatchException;
import java.util.Scanner;

public class Teclado {

    private static final Scanner lectura = new Scanner(System.in);

   
    public static String leerString(String mensaje) throws Exception{
        String cadena = "";
        boolean correcto = false;

        do {
            System.out.print(mensaje);
            try {
                cadena = lectura.nextLine();
                correcto = true;
            } catch (Exception ex) {
                System.out.println("Error en la introducción de la string.");
            }
        } while (!correcto);
        return cadena;
    }

     
    public static float leerFloat(String mensaje) throws InputMismatchException{
        float numero = 0.0f;
        boolean correcto = false;

        do {
            System.out.print(mensaje);
            try {
                numero = lectura.nextFloat();
                correcto = true;
            } catch (InputMismatchException ex) {
                System.out.println("Error de formato.");
            }
            lectura.nextLine();
        } while (!correcto);
        return numero;
    }

     
    public static double leerDouble(String mensaje) throws InputMismatchException{
        double numero = 0.0;
        boolean correcto = false;

        do {
            System.out.print(mensaje);
            try {
                numero = lectura.nextDouble();
                correcto = true;
            } catch (InputMismatchException ex) {
                System.out.println("Error de formato.");
            }
            lectura.nextLine();
        } while (!correcto);
        return numero;
    }

     
    public static int leerInt(String mensaje) throws InputMismatchException{
        int numero = 0;
        boolean correcto = false;

        do {
            System.out.print(mensaje);
            try {
                numero = lectura.nextInt();
                correcto = true;
            } catch (InputMismatchException ex) {
                System.out.println("Error de formato.");
            }
            lectura.nextLine();
        } while (!correcto);
        return numero;
    }
    

    public static byte leerByte(String mensaje) throws InputMismatchException{
        byte numero = 0;
        boolean correcto = false;

        do {
            System.out.print(mensaje);
            try {
                numero = lectura.nextByte();
                correcto = true;
            } catch (InputMismatchException ex) {
                System.out.println("Error de formato.");
            }
            lectura.nextLine();
        } while (!correcto);
        return numero;
    }


    public static char leerChar(String mensaje) throws Exception, InputMismatchException{
        char caracter = 0;
        boolean correcto = false;

        do {
            System.out.print(mensaje);
            try {
                caracter = lectura.next().charAt(0);// 
                correcto = true;
            } catch (InputMismatchException ex) {
                System.out.println("Error de formato.");
            } catch (Exception ex) {
                System.out.println(ex.toString());
            }
            lectura.nextLine();
        } while (!correcto);
        return caracter;
    }
    
    
    public static boolean leerSiNo(String mensaje) throws Exception{
        boolean retorno = false;
        boolean correcto = false;
        String cadena = "";

        do {
            System.out.print(mensaje);
            try {
                cadena = lectura.nextLine().toUpperCase();
                correcto = true;
                if (cadena.charAt(0) == 'S') {
                    retorno = true;
                } else if (cadena.charAt(0) == 'N') {
                    retorno = false;
                } else {
                    System.out.println("Introducción no válida.");
                    correcto = false;
                }
            } catch (Exception ex) {
                System.out.println("Error en la introducción de la string.");
            }
        } while (!correcto);
        return retorno;
    }
}
